export class CreateTctDto {}
